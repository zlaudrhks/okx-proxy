const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(cors());

const OKX_BASE_URL = 'https://www.okx.com';

app.get('/okx/*', async (req, res) => {
  const path = req.params[0];
  const query = req.originalUrl.split('?')[1] || '';
  try {
    const okxRes = await axios.get(`${OKX_BASE_URL}/${path}?${query}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0',
        'Accept': 'application/json'
      }
    });
    res.json(okxRes.data);
  } catch (err) {
    res.status(err.response?.status || 500).json({ error: err.message });
  }
});

const port = process.env.PORT || 10000;
app.listen(port, () => {
  console.log(`✅ OKX proxy server running on port ${port}`);
});
